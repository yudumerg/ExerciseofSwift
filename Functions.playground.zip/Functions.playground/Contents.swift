import UIKit
class fonksiyonlar{
    func donusum (derece:Double) -> Double {
        let fahr = ( derece * 1.8 ) + 32
        return fahr
    }
    func cevreHesapla (kenar1:Double,kenar2:Double) -> Double {
       let cevre = (kenar1 + kenar2) * 2
        return cevre
    }
    func faktoriyelHesapla (sayi:Int) -> Int {
        var i = 1
        var sonuc = 1
        while i <= sayi {
            sonuc = i * sonuc
            i = i + 1
        }
        return sonuc
    }
    func harfKontrol(kelime:String,harf:String) -> Int{
        var sayac = 0
        var i = 0
        while i <= kelime.count{
            if(harf = )
        }
    }
    func icAcilar (kenarSayisi:Int) -> Int{
        let aciToplam = (kenarSayisi - 2) * 180
        return aciToplam
    }
    func maasHesapla (gunSayisi:Int) -> Int {
        if (gunSayisi < 20) {
            let maas = gunSayisi * 10
            return maas
        }
        else {
            let maas = gunSayisi * 20
            return maas
        }
    }
    func ucretHesapla ( miktar: Int) -> Int {
        if (miktar < 50) {
            let ucret = 100
            return ucret
        }
        else {
            let ucret = 100 + (miktar - 50 ) * 4
            return ucret
        }
    }
}
let f = fonksiyonlar()

f.donusum(derece:100)

f.cevreHesapla(kenar1: 10, kenar2: 20)

f.faktoriyelHesapla(sayi: 5)

f.icAcilar(kenarSayisi: 5)

f.maasHesapla(gunSayisi: 30)

f.ucretHesapla(miktar: 70)

